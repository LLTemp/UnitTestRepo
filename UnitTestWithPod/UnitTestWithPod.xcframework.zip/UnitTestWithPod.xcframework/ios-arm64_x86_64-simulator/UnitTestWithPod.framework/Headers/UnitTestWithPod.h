//
//  UnitTestWithPod.h
//  UnitTestWithPod
//
//  Created by SergeyBrazhnik on 18.11.2020.
//

#import <Foundation/Foundation.h>

//! Project version number for UnitTestWithPod.
FOUNDATION_EXPORT double UnitTestWithPodVersionNumber;

//! Project version string for UnitTestWithPod.
FOUNDATION_EXPORT const unsigned char UnitTestWithPodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UnitTestWithPod/PublicHeader.h>


